// index.js — Backend do CAF RN Playground
// Mesmo backend do projeto JS, com CORS liberado para o app mobile (emulador/device).
import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
import jwtLib from "jsonwebtoken";
import { generateAuthJwt, exchangeForMobileToken } from "./caf-auth.js";

dotenv.config();

const {
  CAF_CLIENT_ID:     clientId,
  CAF_CLIENT_SECRET: clientSecret,
  CAF_PROVIDER,
  CAF_EXCHANGE_URL,
  PORT = 3000,
} = process.env;

if (!clientId || !clientSecret) {
  console.error("❌ Configure CAF_CLIENT_ID e CAF_CLIENT_SECRET no .env");
  process.exit(1);
}

const EXCHANGE_URL = CAF_EXCHANGE_URL || "https://web.us.prd.caf.io/bff/session-tokens";
const PROVIDER     = CAF_PROVIDER     || "caf";

const app = express();

// CORS aberto — o app mobile acessa via IP da rede local (ex: 10.0.2.2 no emulador).
// Em produção, restrinja para o domínio/origem do app.
app.use(cors());
app.use(express.json({ limit: "32kb" }));

// Rate limiting
app.use("/api/", rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Muitas requisições. Tente novamente em breve." },
}));

// Health check — útil para o app testar conexão
app.get("/api/health", (_req, res) => res.json({ ok: true, provider: PROVIDER }));

// ─── POST /api/auth/mobile-session ────────────────────────────────────────────
app.post("/api/auth/mobile-session", async (req, res) => {
  try {
    const provider = req.body?.provider || PROVIDER;
    const authJwt  = generateAuthJwt({ clientId, clientSecret, provider });
    const data     = await exchangeForMobileToken({ authJwt, exchangeUrl: EXCHANGE_URL });
    res.json({ ...data, provider });
  } catch (err) {
    console.error("[mobile-session]", err.message);
    res.status(500).json({ error: "Falha ao gerar sessão." });
  }
});

// ─── POST /api/decode-result ──────────────────────────────────────────────────
// Com secret → verifica assinatura HS256 (validação)
// Sem secret → apenas decodifica (debug)
app.post("/api/decode-result", (req, res) => {
  try {
    const { token, secret } = req.body || {};
    if (!token) return res.status(400).json({ error: "token é obrigatório." });

    const complete = jwtLib.decode(token, { complete: true });
    if (!complete) return res.status(400).json({ error: "Token malformado." });
    const { header } = complete;

    if (secret?.trim()) {
      try {
        const payload = jwtLib.verify(token, secret.trim(), { algorithms: ["HS256"] });
        return res.json({ header, payload, verified: true });
      } catch (err) {
        const isSig = ["JsonWebTokenError", "TokenExpiredError", "NotBeforeError"].includes(err.name);
        return res.status(isSig ? 401 : 400).json({
          error: isSig ? "Assinatura inválida ou token expirado." : err.message,
          verified: false,
        });
      }
    }

    res.json({ header, payload: complete.payload, verified: null });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 CAF RN Playground backend em http://localhost:${PORT}`);
  console.log(`   Emulador Android acessa via: http://10.0.2.2:${PORT}`);
  console.log(`   Device físico acessa via: http://<IP-DA-SUA-MAQUINA>:${PORT}`);
  console.log(`   Provider: ${PROVIDER}`);
});
