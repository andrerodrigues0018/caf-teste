// caf-auth.js
import jwt from "jsonwebtoken";
import fetch from "node-fetch";

export function generateAuthJwt({ clientId, clientSecret, ttlSeconds = 300, provider = "caf" }) {
  if (!clientId || !clientSecret) throw new Error("clientId e clientSecret são obrigatórios.");

  const nowSec = Math.floor(Date.now() / 1000);
  const payload = {
    iss: clientId,
    sub: clientId,
    iat: nowSec,
    exp: nowSec + ttlSeconds,
    scope: { face: { provider } },
  };

  return jwt.sign(payload, clientSecret, { algorithm: "HS256" });
}

export async function exchangeForMobileToken({ authJwt, exchangeUrl }) {
  if (!authJwt)     throw new Error("authJwt ausente.");
  if (!exchangeUrl) throw new Error("exchangeUrl ausente.");

  const res = await fetch(exchangeUrl, {
    method: "GET",
    headers: { Accept: "application/json", Authorization: `Bearer ${authJwt}` },
  });

  const raw = await res.text();
  if (!res.ok) throw new Error(`CAF exchange ${res.status}: ${raw}`);

  try { return JSON.parse(raw); } catch { return { raw }; }
}
