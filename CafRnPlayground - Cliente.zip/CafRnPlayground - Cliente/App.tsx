// App.tsx — CAF RN Playground

import React, { useEffect, useState } from 'react';
import {
  SafeAreaView, View, Text, TextInput, TouchableOpacity, StyleSheet, StatusBar,
} from 'react-native';
import { colors, spacing, radius, font } from './src/theme';
import { FlowScreen } from './src/screens/FlowScreen';
import { LogPanel } from './src/components/LogPanel';
import { checkBackend } from './src/services/api';
import { log } from './src/services/useLogStore';
import { config } from './src/services/config';
import BootSplash from 'react-native-bootsplash';

type Tab = 'liveness' | 'faceauth' | 'document';

const TABS: { key: Tab; icon: string; label: string }[] = [
  { key: 'liveness', icon: '👁', label: 'Liveness' },
  { key: 'faceauth', icon: '🔐', label: 'Face Auth' },
  { key: 'document', icon: '📄', label: 'Document' },
];

export default function App() {
  const [tab, setTab] = useState<Tab>('liveness');
  const [personId, setPersonId] = useState('test-user-123');
  const [clientSecret, setClientSecret] = useState('');
  const [showSecret, setShowSecret] = useState(false);
  const [logsOpen, setLogsOpen] = useState(false);
  const [backendOk, setBackendOk] = useState<boolean | null>(null);

  useEffect(() => {
    log('info', 'APP', 'Playground iniciado', { backend: config.backendUrl, env: config.environment });
    checkBackend().then((ok) => {
      setBackendOk(ok);
      log(ok ? 'succ' : 'err', 'APP', ok ? 'Backend conectado ✅' : 'Backend inacessível ❌', { url: config.backendUrl });
    });
    BootSplash.hide({ fade: true });
  }, []);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor={colors.bg} />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.brand}>
          <View style={styles.logo}><Text style={styles.logoTxt}>C</Text></View>
          <View>
            <Text style={styles.brandName}>CAF Playground</Text>
            <Text style={styles.brandSub}>Liveness · Face Auth · Document</Text>
          </View>
        </View>
        <View style={[styles.envPill, backendOk === false && styles.envPillErr]}>
          <Text style={styles.envTxt}>
            {backendOk === null ? '…' : backendOk ? 'online' : 'offline'}
          </Text>
        </View>
      </View>

      {/* Config */}
      <View style={styles.config}>
        <View style={styles.field}>
          <Text style={styles.fieldLabel}>PERSON ID</Text>
          <TextInput
            style={styles.input}
            value={personId}
            onChangeText={setPersonId}
            placeholder="person id"
            placeholderTextColor={colors.text3}
          />
        </View>
        <View style={styles.field}>
          <Text style={styles.fieldLabel}>CLIENT SECRET (opcional — verifica assinatura)</Text>
          <View style={styles.secretRow}>
            <TextInput
              style={[styles.input, { flex: 1 }]}
              value={clientSecret}
              onChangeText={setClientSecret}
              placeholder="cole para validar a assinatura"
              placeholderTextColor={colors.text3}
              secureTextEntry={!showSecret}
              autoCapitalize="none"
              autoCorrect={false}
            />
            <TouchableOpacity onPress={() => setShowSecret((s) => !s)} style={styles.eyeBtn}>
              <Text style={{ fontSize: 16 }}>{showSecret ? '🙈' : '👁'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        {TABS.map((t) => (
          <TouchableOpacity
            key={t.key}
            style={[styles.tab, tab === t.key && styles.tabActive]}
            onPress={() => setTab(t.key)}
          >
            <Text style={styles.tabIcon}>{t.icon}</Text>
            <Text style={[styles.tabLabel, tab === t.key && styles.tabLabelActive]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Content */}
      <View style={{ flex: 1 }}>
        {tab === 'liveness' && (
          <FlowScreen
            mode="liveness" title="Prova de Vida"
            subtitle="Valida que há uma pessoa real diante da câmera (liveness puro, sem autenticação facial)."
            buttonLabel="▶ Iniciar Liveness"
            personId={personId} clientSecret={clientSecret}
          />
        )}
        {tab === 'faceauth' && (
          <FlowScreen
            mode="faceauth" title="Autenticação Facial"
            subtitle="Liveness + comparação facial (executeFaceAuth) para autenticar o usuário."
            buttonLabel="▶ Iniciar Face Auth"
            personId={personId} clientSecret={clientSecret}
          />
        )}
        {tab === 'document' && (
          <FlowScreen
            mode="document" title="Document Detector"
            subtitle="Captura e processa documentos (RG, CNH, Passaporte, etc.) com telas de instrução."
            buttonLabel="▶ Iniciar Captura"
            personId={personId} clientSecret={clientSecret}
          />
        )}
      </View>

      {/* Logs FAB */}
      <TouchableOpacity style={styles.fab} onPress={() => setLogsOpen(true)}>
        <Text style={styles.fabTxt}>📋 Logs</Text>
      </TouchableOpacity>

      <LogPanel visible={logsOpen} onClose={() => setLogsOpen(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  brand: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  logo: {
    width: 40, height: 40, borderRadius: radius.md, backgroundColor: colors.certta,
    alignItems: 'center', justifyContent: 'center',
  },
  logoTxt: { color: '#fff', fontWeight: '700', fontSize: 20 },
  brandName: { fontSize: 16, fontWeight: '700', color: colors.text },
  brandSub: { fontSize: 11, color: colors.text3 },
  envPill: {
    paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.pill,
    backgroundColor: colors.certtaSoft,
  },
  envPillErr: { backgroundColor: colors.errSoft },
  envTxt: { fontSize: 11, color: colors.certta, fontFamily: font.mono, fontWeight: '600' },
  config: { paddingHorizontal: spacing.lg, paddingTop: spacing.md, gap: spacing.sm },
  field: { gap: 4 },
  fieldLabel: { fontSize: 10, color: colors.text3, fontWeight: '700', letterSpacing: 0.5 },
  input: {
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.sm, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    color: colors.text, fontFamily: font.mono, fontSize: 13,
  },
  secretRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  eyeBtn: {
    width: 42, height: 42, alignItems: 'center', justifyContent: 'center',
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm,
  },
  tabs: {
    flexDirection: 'row', margin: spacing.lg, padding: 4,
    backgroundColor: colors.surface2, borderRadius: radius.md, gap: 2,
  },
  tab: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    paddingVertical: spacing.sm, borderRadius: radius.sm,
  },
  tabActive: { backgroundColor: colors.surface },
  tabIcon: { fontSize: 15 },
  tabLabel: { fontSize: 12, fontWeight: '600', color: colors.text3 },
  tabLabelActive: { color: colors.certta },
  fab: {
    position: 'absolute', right: spacing.lg, bottom: spacing.xl,
    backgroundColor: colors.certta, paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderRadius: radius.pill, shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 }, elevation: 5,
  },
  fabTxt: { color: '#fff', fontWeight: '700', fontSize: 13 },
});
