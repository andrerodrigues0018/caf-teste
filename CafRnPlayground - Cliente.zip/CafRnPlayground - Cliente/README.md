# Certta Playground — React Native

Projeto de exemplo para integrar e testar os módulos **Liveness**, **Face Auth** e **Document Detector** da Certta em React Native. Use como ponto de partida da sua integração e como ambiente para validar o comportamento dos SDKs.

> 📖 **Para um guia visual completo, abra o arquivo `GUIA.html` no navegador.** Ele cobre setup, arquitetura, verificação de assinatura, geração de APK e solução de problemas.

> 🔒 O `clientSecret` **nunca** vai para o app. O app pede o token a um backend Node.js que assina e troca pelo session token. O campo "Client Secret" na tela serve **apenas** para validar a assinatura do resultado.

---

## Escopo

Este projeto cobre a jornada de captura **até a geração dos resultados assinados (JWTs)**. O envio desses resultados para o processamento da Certta é **outra integração** e não faz parte deste exemplo.

---

## Pré-requisitos

- **Node.js 18**
- **React Native 0.73.x** com ambiente configurado (Android Studio + emulador, ou device físico)
- Android: minSdk 26, compileSdk 34, Kotlin 1.9.10, Gradle 8.4
- Suas credenciais Certta: `CAF_CLIENT_ID` e `CAF_CLIENT_SECRET` — disponíveis na plataforma Trust em https://trust.caf.io/access-keys

> ⚠️ Use o SDK `@caf.io/react-native-sdk` em versão **≥ 4.3.0** (abaixo disso o iProov fica inoperante a partir de março/2026).

---

## 1. Backend (gera o token)

```bash
cd backend
copy .env.example .env      # preencha com suas credenciais
npm install
npm run dev
```

O backend sobe em `http://localhost:3000`. Deixe rodando.

---

## 2. App React Native

```bash
# na raiz do projeto
npm install
```

O app resolve a URL do backend automaticamente:

| Cenário | URL usada |
|---|---|
| Emulador Android | `http://10.0.2.2:3000` |
| Emulador iOS | `http://localhost:3000` |
| Device físico | defina `MANUAL_BACKEND_URL` em `src/services/config.ts` |

### Rodar

```bash
npm run android
```

A primeira build demora alguns minutos (compila dependências nativas). É normal.

---

## 3. Documentos de teste

A pasta `assets-teste/` traz documentos de exemplo. Envie um para o emulador antes de usar o upload do Document Detector:

```bash
adb push "assets-teste\rg-frente.jpg" /sdcard/Download/
```

---

## 4. Verificação de assinatura (opcional)

1. Rode qualquer fluxo normalmente.
2. Cole o seu `clientSecret` no campo do topo.
3. Toque em **🔐 Verificar assinatura**.

- **Válida** → banner verde. **Inválida** → banner vermelho.

---

## 5. Gerar APK

```bash
cd android
gradlew assembleDebug
cd ..
```

APK em: `android\app\build\outputs\apk\debug\app-debug.apk`

> O APK precisa alcançar o backend. Ajuste `MANUAL_BACKEND_URL` em `config.ts` para um endereço acessível pelo device **antes** de gerar o APK.

---

## Estrutura do projeto

```
certta-rn-playground/
├── GUIA.html                 Guia visual completo (abra no navegador)
├── README.md                 Este arquivo
├── App.tsx                   Abas + barra de config + header
├── caf-modules-config.json   Módulos do SDK habilitados
├── package.json
│
├── backend/                  Node.js — gera token e verifica assinatura
│   ├── index.js              Rotas Express
│   ├── caf-auth.js           Geração do JWT + exchange
│   ├── package.json
│   └── .env.example          Modelo de credenciais (copie para .env)
│
├── src/
│   ├── theme.ts              Cores e tokens visuais
│   ├── services/
│   │   ├── api.ts            Chamadas HTTP ao backend
│   │   ├── config.ts         URL do backend por ambiente
│   │   ├── useCafFlow.ts     Lógica do SDK (Liveness / Auth / Document)
│   │   └── useLogStore.ts    Store de logs em memória
│   ├── components/
│   │   ├── LogPanel.tsx      Painel de logs
│   │   └── ResultCard.tsx    Resultado + banner de verificação
│   └── screens/
│       └── FlowScreen.tsx    Tela reutilizada pelas 3 abas
│
├── assets-teste/             Documentos de exemplo para upload
├── android/                  Projeto nativo Android
└── ios/                      Projeto nativo iOS
```

---

## Solução de problemas

Consulte a seção **Problemas comuns** no `GUIA.html` para: Error 601 (SECURITY_EXCEPTION), minSdkVersion, backend offline, webcam no emulador, upload de documentos e mais.