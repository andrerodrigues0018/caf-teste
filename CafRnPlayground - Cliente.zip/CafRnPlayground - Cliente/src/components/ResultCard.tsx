// ResultCard.tsx — exibe resultado do flow + banner de verificação de assinatura

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, spacing, radius, font } from '../theme';

export function VerifyBanner({ verified }: { verified: boolean | null | undefined }) {
  if (verified === null || verified === undefined) return null;
  return (
    <View style={[styles.banner, verified ? styles.bannerOk : styles.bannerFail]}>
      <Text style={styles.bannerIcon}>{verified ? '🔐' : '⚠️'}</Text>
      <Text style={[styles.bannerTxt, { color: verified ? colors.ok : colors.err }]}>
        {verified
          ? 'Assinatura JWT válida — secret confere com o token'
          : 'Assinatura JWT inválida — token pode ter sido adulterado'}
      </Text>
    </View>
  );
}

export function Chip({ label, type = 'neu' }: { label: string; type?: 'ok' | 'err' | 'warn' | 'info' | 'neu' }) {
  const map = {
    ok:   { bg: colors.okSoft,   fg: colors.ok },
    err:  { bg: colors.errSoft,  fg: colors.err },
    warn: { bg: colors.warnSoft, fg: colors.warn },
    info: { bg: colors.infoSoft, fg: colors.info },
    neu:  { bg: colors.surface2, fg: colors.text3 },
  }[type];
  return (
    <View style={[styles.chip, { backgroundColor: map.bg }]}>
      <Text style={[styles.chipTxt, { color: map.fg }]}>{label}</Text>
    </View>
  );
}

export function ResultCard({
  title, verified, chips, payload,
}: {
  title: string;
  verified?: boolean | null;
  chips?: { label: string; type?: 'ok' | 'err' | 'warn' | 'info' | 'neu' }[];
  payload?: Record<string, any> | null;
}) {
  return (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>{title}</Text>
      <VerifyBanner verified={verified} />
      {chips && chips.length > 0 && (
        <View style={styles.chipsRow}>
          {chips.map((c, i) => <Chip key={i} label={c.label} type={c.type} />)}
        </View>
      )}
      {payload && (
        <View style={styles.payloadBox}>
          <Text style={styles.payloadTxt}>{JSON.stringify(payload, null, 2)}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1,
    borderColor: colors.border, padding: spacing.lg, marginTop: spacing.md,
  },
  cardTitle: { fontSize: 13, fontWeight: '700', color: colors.text, marginBottom: spacing.sm },
  banner: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    padding: spacing.md, borderRadius: radius.md, marginBottom: spacing.sm, borderWidth: 1,
  },
  bannerOk:   { backgroundColor: colors.okSoft,  borderColor: 'rgba(27,122,74,0.2)' },
  bannerFail: { backgroundColor: colors.errSoft, borderColor: 'rgba(192,57,43,0.2)' },
  bannerIcon: { fontSize: 18 },
  bannerTxt:  { fontSize: 12, fontWeight: '600', flex: 1 },
  chipsRow:   { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginBottom: spacing.sm },
  chip:       { paddingHorizontal: spacing.sm, paddingVertical: 3, borderRadius: radius.pill },
  chipTxt:    { fontSize: 11, fontWeight: '600' },
  payloadBox: { backgroundColor: '#1A1916', borderRadius: radius.md, padding: spacing.md, marginTop: spacing.xs },
  payloadTxt: { fontSize: 11, color: '#C8E6C9', fontFamily: font.mono },
});
