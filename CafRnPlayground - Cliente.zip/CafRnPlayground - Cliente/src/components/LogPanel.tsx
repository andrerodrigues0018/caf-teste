// LogPanel.tsx — painel de logs (modal deslizante de baixo)

import React from 'react';
import {
  Modal, View, Text, ScrollView, TouchableOpacity, StyleSheet,
} from 'react-native';
import { colors, spacing, radius, font } from '../theme';
import { useLogs, logStore, LogLevel } from '../services/useLogStore';

const levelColor: Record<LogLevel, string> = {
  info: colors.info,
  succ: colors.ok,
  warn: colors.warn,
  err:  colors.err,
  ev:   colors.ev,
};

export function LogPanel({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const logs = useLogs();

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <View style={styles.sheet}>
          <View style={styles.header}>
            <Text style={styles.title}>Logs passo a passo</Text>
            <View style={styles.headerActions}>
              <Text style={styles.count}>{logs.length}</Text>
              <TouchableOpacity onPress={() => logStore.clear()} style={styles.clearBtn}>
                <Text style={styles.clearTxt}>✕ Limpar</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
                <Text style={styles.closeTxt}>Fechar</Text>
              </TouchableOpacity>
            </View>
          </View>

          <ScrollView style={styles.list} contentContainerStyle={{ paddingBottom: spacing.xl }}>
            {logs.length === 0 && (
              <Text style={styles.empty}>Nenhum log ainda. Inicie um fluxo.</Text>
            )}
            {logs.map((item) => (
              <View
                key={item.seq}
                style={[
                  styles.row,
                  item.level === 'err'  && { backgroundColor: colors.errSoft },
                  item.level === 'succ' && { backgroundColor: colors.okSoft },
                ]}
              >
                <View style={styles.rowHead}>
                  <Text style={styles.seq}>#{String(item.seq).padStart(3, '0')}</Text>
                  <Text style={[styles.level, { color: levelColor[item.level] }]}>
                    {item.level.toUpperCase()}
                  </Text>
                  <Text style={styles.scope}>{item.scope}</Text>
                  <Text style={styles.time}>
                    {new Date(item.t).toLocaleTimeString('pt-BR', { hour12: false })}
                  </Text>
                </View>
                <Text style={styles.msg}>{item.msg}</Text>
                {item.data !== undefined && item.data !== null && (
                  <Text style={styles.data} numberOfLines={8}>
                    {typeof item.data === 'string' ? item.data : JSON.stringify(item.data, null, 2)}
                  </Text>
                )}
              </View>
            ))}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.3)' },
  sheet: {
    height: '75%',
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
  },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    padding: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  title: { fontSize: 15, fontWeight: '700', color: colors.text },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  count: { fontSize: 12, color: colors.text3, fontFamily: font.mono },
  clearBtn: { paddingHorizontal: spacing.sm, paddingVertical: spacing.xs, borderRadius: radius.sm, backgroundColor: colors.errSoft },
  clearTxt: { fontSize: 12, color: colors.err, fontWeight: '600' },
  closeBtn: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.sm, backgroundColor: colors.certta },
  closeTxt: { fontSize: 12, color: '#fff', fontWeight: '600' },
  list: { paddingHorizontal: spacing.lg },
  empty: { color: colors.text3, textAlign: 'center', marginTop: spacing.xl },
  row: { paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border, paddingHorizontal: spacing.sm, borderRadius: radius.sm },
  rowHead: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: 2 },
  seq: { fontSize: 10, fontWeight: '700', color: colors.certta, fontFamily: font.mono },
  level: { fontSize: 10, fontWeight: '700', fontFamily: font.mono },
  scope: { fontSize: 11, color: colors.certta, fontFamily: font.mono },
  time: { fontSize: 10, color: colors.text3, fontFamily: font.mono, marginLeft: 'auto' },
  msg: { fontSize: 12, color: colors.text, lineHeight: 17 },
  data: {
    fontSize: 11, color: colors.certta, fontFamily: font.mono,
    backgroundColor: colors.bg, borderRadius: radius.sm, padding: spacing.sm, marginTop: spacing.xs,
  },
});
