// theme.ts — Tokens visuais Certta para React Native

export const colors = {
  // Base
  bg:        '#F5F4F0',  // off-white quente
  surface:   '#FFFFFF',
  surface2:  '#F0EFE9',
  border:    '#DDD9D0',
  border2:   '#C8C4BA',

  // Texto
  text:      '#1A1916',
  text2:     '#5C5A54',
  text3:     '#9A9790',

  // Certta brand
  certta:     '#1B4D3E',  // verde musgo profundo
  certtaMid:  '#2D6B57',
  certtaSoft: '#EAF2EE',

  // Dourado
  gold:      '#B8860B',
  goldSoft:  '#FBF5E2',

  // Semânticos
  ok:        '#1B7A4A',
  okSoft:    '#E8F5EE',
  warn:      '#B8701A',
  warnSoft:  '#FEF4E6',
  err:       '#C0392B',
  errSoft:   '#FDEEEC',
  info:      '#1A4B7A',
  infoSoft:  '#EBF2FC',

  // Eventos (roxo)
  ev:        '#7C3AED',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

export const radius = {
  sm: 8,
  md: 10,
  lg: 14,
  pill: 999,
};

export const font = {
  regular: 'System',
  mono: 'Courier',
};

// Configuração de cores para o SDK CAF (CafColorConfiguration)
export const cafColorConfiguration = {
  primaryColor:          colors.certta,
  secondaryColor:        colors.certtaMid,
  backgroundColor:       colors.surface,
  contentColor:          colors.text,
  mediumColor:           colors.border2,
  dialogBackgroundColor: colors.surface,
  dialogBorderColor:     colors.border,
};
