// useLogStore.ts — store de logs compartilhado entre as telas (singleton simples)

import { useSyncExternalStore } from 'react';

export type LogLevel = 'info' | 'succ' | 'warn' | 'err' | 'ev';

export interface LogItem {
  seq: number;
  t: string;
  level: LogLevel;
  scope: string;
  msg: string;
  data?: any;
}

let logs: LogItem[] = [];
let seq = 0;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}

export const logStore = {
  add(level: LogLevel, scope: string, msg: string, data?: any) {
    seq++;
    logs = [...logs, { seq, t: new Date().toISOString(), level, scope, msg, data }];
    emit();
  },
  clear() {
    logs = [];
    seq = 0;
    emit();
  },
  getAll(): LogItem[] {
    return logs;
  },
  subscribe(listener: () => void) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },
};

export function useLogs(): LogItem[] {
  return useSyncExternalStore(logStore.subscribe, logStore.getAll);
}

// Helper curto
export const log = (level: LogLevel, scope: string, msg: string, data?: any) =>
  logStore.add(level, scope, msg, data);
