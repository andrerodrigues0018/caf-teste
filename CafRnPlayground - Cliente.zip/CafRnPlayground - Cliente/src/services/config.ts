// config.ts — Configuração de ambiente do app
//
// O backend Node.js é acessado por URLs diferentes dependendo de onde o app roda:
//   - Emulador Android  → http://10.0.2.2:3000  (10.0.2.2 = localhost da máquina host)
//   - Emulador iOS      → http://localhost:3000
//   - Device físico     → http://<IP-DA-SUA-MAQUINA>:3000  (mesma rede Wi-Fi)
//
// Ajuste BACKEND_URL conforme seu cenário de teste.

import { Platform } from 'react-native';

// Troque pelo IP da sua máquina ao testar em device físico.
// Ex: 'http://192.168.0.42:3000'
const MANUAL_BACKEND_URL = '';

function resolveBackendUrl(): string {
  if (MANUAL_BACKEND_URL) return MANUAL_BACKEND_URL;
  if (Platform.OS === 'android') return 'http://10.0.2.2:3000';
  return 'http://localhost:3000';
}

export const config = {
  backendUrl: resolveBackendUrl(),
  environment: 'PROD' as const, // PROD | BETA | DEV
};
