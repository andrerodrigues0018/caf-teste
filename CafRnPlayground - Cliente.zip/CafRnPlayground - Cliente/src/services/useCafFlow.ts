// useCafFlow.ts — encapsula a lógica do SDK CAF compartilhada pelas telas
//
// Cada tela usa este hook com um "mode" diferente:
//   - 'liveness'  → FACE_LIVENESS_UI, executeFaceAuth: false
//   - 'faceauth'  → FACE_LIVENESS_UI, executeFaceAuth: true
//   - 'document'  → DOCUMENT_DETECTOR_UI

import { useEffect, useState, useRef } from 'react';
import {
  useCafSdk,
  useCafFaceLivenessUI,
  useCafDocumentDetectorUI,
  CafModuleType,
  CafEnvironment,
  CafDocument,
  CafFileFormat,
} from '@caf.io/react-native-sdk';

import { getMobileSession, decodeResult, DecodeResult } from './api';
import { config } from './config';
import { cafColorConfiguration } from '../theme';
import { log } from './useLogStore';

export type FlowMode = 'liveness' | 'faceauth' | 'document';

export interface FlowResult {
  payload: Record<string, any>;
  verified: boolean | null;
  raw: DecodeResult;
}

export function useCafFlow(mode: FlowMode, personId: string, clientSecret: string) {
  const { initialize, startSDK, response, initialized } = useCafSdk();
  const { applyCafFaceLivenessUI } = useCafFaceLivenessUI();
  const { applyCafDocumentDetectorUI } = useCafDocumentDetectorUI();

  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<FlowResult | null>(null);
  const lastJwt = useRef<string | null>(null);

  const envMap = {
    PROD: CafEnvironment.PROD,
    BETA: CafEnvironment.BETA,
    DEV:  CafEnvironment.DEV,
  } as const;

  // ─── Inicia o flow ───────────────────────────────────────────────────────────
  async function start() {
    if (running) {
      log('warn', mode.toUpperCase(), 'Fluxo já em execução.');
      return;
    }
    setRunning(true);
    setResult(null);

    try {
      // 1 — Token via backend
      log('info', 'AUTH', `Gerando token de sessão [${mode}]…`);
      const { token, raw } = await getMobileSession(mode);
      log('succ', 'AUTH', 'Token obtido ✅', { length: token.length, provider: raw.provider });

      // 2 — Configura módulo conforme o mode
      const moduleType =
        mode === 'document' ? CafModuleType.DOCUMENT_DETECTOR_UI : CafModuleType.FACE_LIVENESS_UI;

      log('info', mode.toUpperCase(), 'Inicializando SDK…', { module: moduleType, personId });

      const ok = await initialize(
        {
          mobileToken: token,
          personId: personId || 'user',
          environment: envMap[config.environment],
          configuration: {
            presentationOrder: [moduleType],
            // Em emulador/device de teste, o módulo de segurança bloqueia (Error 601).
            // Desligado para permitir testes. EM PRODUÇÃO, deixe true.
            enableSecurityModule: false,
            colorConfiguration: cafColorConfiguration,
          },
        },
        async () => {
          if (mode === 'document') {
            return applyCafDocumentDetectorUI({
              configuration: {
                flow: [{ document: CafDocument.ANY }],
                manualCaptureEnabled: true,
                manualCaptureTime: 30,
                requestTimeout: 60,
                showPopup: true,
                maxRetryAttempts: 2,
                uploadSettings: {
                  enable: true,
                  compress: true,
                  fileFormats: [CafFileFormat.PNG, CafFileFormat.JPG, CafFileFormat.JPEG, CafFileFormat.PDF],
                  maxFileSize: 10 * 1024 * 1024, // 10MB em BYTES (a unidade é byte, não MB)
                },
                securitySettings: { useDebug: true, useDevelopmentMode: true, useAdb: true },
              },
              instructionScreenConfiguration: {
                enable: true,
                captureTitle: 'Capture seu documento',
                captureSteps: ['Mantenha o celular firme', 'Boa iluminação', 'Evite reflexos'],
                buttonText: 'Iniciar captura',
              },
              documentSelectionScreenConfiguration: {
                title: 'Selecione o tipo de documento',
                description: 'Escolha qual documento deseja enviar',
              },
            });
          }

          // Liveness ou Face Auth
          return applyCafFaceLivenessUI({
            configuration: {
              executeFaceAuth: mode === 'faceauth',
              maxRetryAttempts: 2,
              debugModeEnabled: true,
              screenCaptureEnabled: true, // ajuda em emulador/screen recording
            },
            instructionScreenConfiguration: {
              image: 'face_scan_icon',
              title: mode === 'faceauth' ? 'Autenticação facial' : 'Prova de vida',
              description: 'Vamos verificar sua identidade',
              steps: ['Posicione o rosto', 'Boa iluminação', 'Siga as instruções'],
              buttonText: mode === 'faceauth' ? 'Autenticar' : 'Iniciar',
            },
          });
        }
      );

      if (!ok) {
        log('err', mode.toUpperCase(), 'Falha ao aplicar configurações do SDK.');
        setRunning(false);
        return;
      }

      log('succ', mode.toUpperCase(), 'SDK inicializado — abrindo captura…');
      startSDK();
    } catch (e: any) {
      log('err', mode.toUpperCase(), e.message, { stack: e.stack });
      setRunning(false);
    }
  }

  // ─── Reage aos eventos do SDK ──────────────────────────────────────────────────
  useEffect(() => {
    if (response.log) {
      const txt = typeof response.log === 'string' ? response.log : JSON.stringify(response.log);
      log('info', 'SDK', txt);
    }
  }, [response.log]);

  useEffect(() => {
    if (response.error) {
      const errStr = JSON.stringify(response.error);
      log('err', 'SDK', `Erro: ${errStr}`);
      // Dica amigável para o erro de câmera no liveness (comum em emulador)
      if (mode !== 'document' && /camera|liveness/i.test(errStr)) {
        log('warn', 'DICA', 'Liveness exige câmera real. Em emulador o iProov costuma falhar — teste em um device físico.');
      }
      setRunning(false);
    }
  }, [response.error]);

  useEffect(() => {
    if (response.failure) {
      log('warn', 'SDK', `Falha: ${JSON.stringify(response.failure)}`);
      setRunning(false);
    }
  }, [response.failure]);

  useEffect(() => {
    if (response.cancelled) {
      log('warn', mode.toUpperCase(), 'Fluxo cancelado pelo usuário.');
      setRunning(false);
    }
  }, [response.cancelled]);

  useEffect(() => {
    const successList = response.success;
    if (!successList?.length) return;

    (async () => {
      for (const item of successList) {
        // signedResponse pode vir como string (JWT direto) ou objeto com o JWT dentro.
        // Extraímos a string de forma defensiva.
        const sr: any = item.signedResponse;
        const jwt: string | null =
          typeof sr === 'string'
            ? sr
            : sr?.signedResponse || sr?.token || sr?.jwt || sr?.signedResult || null;

        if (!jwt) {
          log('warn', item.moduleName, 'signedResponse sem JWT reconhecível', { raw: sr });
          continue;
        }

        lastJwt.current = jwt;
        log('succ', item.moduleName, 'signedResponse recebido ✅', { length: jwt.length });

        // Decodifica + verifica assinatura (se secret informado)
        const decoded = await decodeResult(jwt, clientSecret || null);
        if (decoded.verified === true)  log('succ', 'JWT', 'Assinatura verificada com o secret ✅');
        else if (decoded.verified === false) log('err', 'JWT', 'Secret inválido — assinatura não confere');
        else log('info', 'JWT', 'JWT decodificado sem verificação de assinatura');

        setResult({ payload: decoded.payload, verified: decoded.verified, raw: decoded });
      }
      setRunning(false);
    })();
  }, [response.success]);

  // ─── Reverifica o último JWT com o secret atual (botão "Verificar") ───────────
  async function reverify() {
    if (!lastJwt.current) {
      log('warn', 'JWT', 'Nenhum JWT capturado ainda.');
      return;
    }
    log('info', 'JWT', 'Reverificando assinatura com o secret informado…');
    const decoded = await decodeResult(lastJwt.current, clientSecret || null);
    if (decoded.verified === true)  log('succ', 'JWT', 'Assinatura verificada ✅');
    else if (decoded.verified === false) log('err', 'JWT', 'Secret inválido ✕');
    setResult((prev) => prev ? { ...prev, verified: decoded.verified, raw: decoded } : { payload: decoded.payload, verified: decoded.verified, raw: decoded });
  }

  return { start, reverify, running, result, hasCapture: !!lastJwt.current };
}