// api.ts — Comunicação com o backend Node.js

import { config } from './config';

export interface MobileSession {
  mobile_token?: string;
  sessionToken?: string;
  token?: string;
  provider?: string;
  [key: string]: any;
}

export interface DecodeResult {
  header: Record<string, any>;
  payload: Record<string, any>;
  verified: boolean | null; // true = válido, false = inválido, null = não verificado
  error?: string;
}

/**
 * Gera o mobileToken via backend (que assina o JWT e troca pelo session token).
 */
export async function getMobileSession(scope = 'liveness'): Promise<{ token: string; raw: MobileSession }> {
  const res = await fetch(`${config.backendUrl}/api/auth/mobile-session`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ scope }),
  });

  const data: MobileSession = await res.json();
  if (!res.ok) throw new Error((data as any).error || `HTTP ${res.status}`);

  const token = data.mobile_token || data.sessionToken || data.token;
  if (!token) {
    throw new Error(`Token não encontrado. Campos: ${Object.keys(data).join(', ')}`);
  }

  return { token, raw: data };
}

/**
 * Decodifica (e opcionalmente verifica) o signedResponse retornado pelo SDK.
 * Se `secret` for informado, o backend valida a assinatura HS256.
 */
export async function decodeResult(token: string, secret?: string | null): Promise<DecodeResult> {
  const res = await fetch(`${config.backendUrl}/api/decode-result`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token, secret: secret || undefined }),
  });

  const data = await res.json();
  if (!res.ok) {
    return { header: {}, payload: {}, verified: false, error: data.error };
  }
  return data;
}

/**
 * Testa a conexão com o backend.
 */
export async function checkBackend(): Promise<boolean> {
  try {
    const res = await fetch(`${config.backendUrl}/api/health`);
    return res.ok;
  } catch {
    return false;
  }
}
