// FlowScreen.tsx — tela genérica usada pelas 3 abas (Liveness, Face Auth, Document)

import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet,
} from 'react-native';
import { colors, spacing, radius, font } from '../theme';
import { useCafFlow, FlowMode } from '../services/useCafFlow';
import { ResultCard } from '../components/ResultCard';

interface Props {
  mode: FlowMode;
  title: string;
  subtitle: string;
  buttonLabel: string;
  personId: string;
  clientSecret: string;
}

export function FlowScreen({ mode, title, subtitle, buttonLabel, personId, clientSecret }: Props) {
  const { start, reverify, running, result, hasCapture } = useCafFlow(mode, personId, clientSecret);

  function buildChips() {
    if (!result) return [];
    const p = result.payload || {};
    if (mode === 'document') {
      return [
        { label: `Tipo: ${p.documentType || p.type || '?'}`, type: 'info' as const },
        { label: p.isValid ?? p.isCaptureValid ? 'Válido ✅' : 'Verificar ⚠️', type: 'info' as const },
      ];
    }
    const chips = [
      { label: p.isAlive ? 'Liveness: PASSOU ✅' : 'Liveness: ?', type: (p.isAlive ? 'ok' : 'warn') as const },
    ];
    if (mode === 'faceauth') {
      chips.push({ label: p.isMatch ? 'Auth: MATCH ✅' : 'Auth: ?', type: (p.isMatch ? 'ok' : 'warn') as const });
    }
    return chips;
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: spacing.lg }}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.subtitle}>{subtitle}</Text>

      <TouchableOpacity
        style={[styles.btn, running && styles.btnDisabled]}
        onPress={start}
        disabled={running}
      >
        <Text style={styles.btnTxt}>{running ? 'Rodando…' : buttonLabel}</Text>
      </TouchableOpacity>

      {hasCapture && (
        <TouchableOpacity
          style={[styles.btnSecondary, !clientSecret && styles.btnDisabled]}
          onPress={reverify}
          disabled={!clientSecret}
        >
          <Text style={styles.btnSecondaryTxt}>🔐 Verificar assinatura</Text>
        </TouchableOpacity>
      )}

      {result && (
        <ResultCard
          title="Resultado"
          verified={result.verified}
          chips={buildChips()}
          payload={result.payload}
        />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  title: { fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: spacing.xs },
  subtitle: { fontSize: 13, color: colors.text2, marginBottom: spacing.xl, lineHeight: 19 },
  btn: {
    backgroundColor: colors.certta, paddingVertical: spacing.md, borderRadius: radius.md,
    alignItems: 'center', marginBottom: spacing.sm,
  },
  btnDisabled: { opacity: 0.5 },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 15 },
  btnSecondary: {
    backgroundColor: colors.goldSoft, paddingVertical: spacing.md, borderRadius: radius.md,
    alignItems: 'center', borderWidth: 1, borderColor: 'rgba(184,134,11,0.25)',
  },
  btnSecondaryTxt: { color: colors.gold, fontWeight: '700', fontSize: 14 },
});
